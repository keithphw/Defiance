/*
 * ByteServer.java
 *
 * Created on 15 July 2007, 20:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package sydneyengine.network;

import java.io.*;

/**
 *
 * @author Keith
 */
public interface ByteServer extends ByteServerOrClient{
}
