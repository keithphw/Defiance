/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sydneyengine.network;
public class JGNByteArrayMessage{}
/*
import com.captiveimagination.jgn.message.*;
import com.captiveimagination.jgn.message.type.*;

public class JGNByteArrayMessage extends Message implements CertifiedMessage, TimestampedMessage, PlayerMessage {
	protected byte[] bytes;

	public JGNByteArrayMessage(){
	}
	public JGNByteArrayMessage(byte[] bytes){
		this.bytes = bytes;
	}
	public byte[] getBytes() {
		return bytes;
	}
	
}*/