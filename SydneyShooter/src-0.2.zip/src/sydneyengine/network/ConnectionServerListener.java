/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sydneyengine.network;

/**
 *
 * @author woodwardk
 */
public interface ConnectionServerListener {
	public void connectionMade(ByteServer byteServer);
}
