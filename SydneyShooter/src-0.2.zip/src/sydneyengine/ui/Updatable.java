/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sydneyengine.ui;

/**
 *
 * @author woodwardk
 */
public interface Updatable {
	public void doMove(double seconds, double timeAtStartOfMoveSeconds);
}
