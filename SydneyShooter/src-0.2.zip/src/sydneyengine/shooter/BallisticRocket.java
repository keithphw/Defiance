/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sydneyengine.shooter;

import sydneyengine.superserializable.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;

/**
 *
 * @author CommanderKeith
 */
public class BallisticRocket extends Bullet {

	static float canNotHitOwnPlayerTimeSeconds = 1.0f;
	public float maxRange;
	float length;
	float maxSpeed;
	float damage;
	float angle;
	float accelX;
	float accelY;

	public BallisticRocket() {
		super();
	}

	public BallisticRocket(Player player, float newX, float newY, float angle, double spawnTimeSeconds, float xLaunchSpeed, float yLaunchSpeed) {
		super(player, newX, newY, angle, spawnTimeSeconds, xLaunchSpeed, yLaunchSpeed);
		assert Point2D.distance(player.getX(), player.getY(), newX, newY) < player.getR() : Point2D.distance(player.getX(), player.getY(), newX, newY);
		length = 10f;
		this.angle = angle;
		
		float startSpeed = 20;
		float accel = 600;
		//maxSpeed = 500;
		damage = 100;
		maxRange = 2000;
		speedX = xLaunchSpeed + (float) Math.cos(angle) * startSpeed;
		speedY = yLaunchSpeed + (float) Math.sin(angle) * startSpeed;
		accelX = (float) Math.cos(angle) * accel;
		accelY = (float) Math.sin(angle) * accel;

		this.x = newX + (float) Math.cos(angle) * length;
		this.y = newY + (float) Math.sin(angle) * length;
		backX = newX;
		backY = newY;
		oldBackX = backX;
		oldBackY = backY;
	}
	
	transient BasicStroke stroke = new BasicStroke(5);
	public void render(ViewPane viewPane) {
		Graphics2D g = viewPane.getBackImageGraphics2D();
		g.setColor(Color.RED);
		//g.fill(new java.awt.geom.Ellipse2D.Float(getX() - radius, getY() - radius, radius * 2f, radius * 2f));
		//System.out.println(this.getClass().getSimpleName()+": render!!!");
		Stroke oldStroke = g.getStroke();
		g.setStroke(stroke);
		g.draw(new Line2D.Float(x, y, backX, backY));//,(float)(x+length*Math.cos(angle)), (float)(y+length*Math.sin(angle))));
		//g.setColor(Color.PINK);
		//g.draw(new Line2D.Float(backX,backY, oldBackX, oldBackY));
		g.setStroke(oldStroke);
	}
	
	public float getAccelX(){
		return accelX;
	}
	public float getAccelY(){
		return accelY;
	}
	public float getDamage(){
		return damage;
	}

	public double getLifeTimeSeconds(){
		return maxRange / maxSpeed;
	}
	public float getLength(){
		return length;
	}
	public float getCanNotHitOwnPlayerTimeSeconds(){
		return canNotHitOwnPlayerTimeSeconds;
	}
}



/*

package sydneyengine;

import sydneyengine.superserializable.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;

public class BallisticRocket extends Bullet {

	static float canNotHitOwnPlayerTimeSeconds = 2.0f;
	protected float maxRange;
	float length;
	float startSpeed;
	float accel;
	float accelX = 0f;
	float accelY = 0f;
	//float maxSpeed;
	float damage;
	float angle;
	float backX;
	float backY;
	float oldBackX;
	float oldBackY;

	public BallisticRocket() {
		super();
	}

	public BallisticRocket(Player player, float newX, float newY, float angle, double spawnTimeSeconds, float xLaunchSpeed, float yLaunchSpeed) {
		super(player, newX, newY, angle, spawnTimeSeconds, xLaunchSpeed, yLaunchSpeed);
		assert Point2D.distance(player.getX(), player.getY(), newX, newY) < player.getR() : Point2D.distance(player.getX(), player.getY(), newX, newY);
		length = 10f;
		this.angle = angle;
		startSpeed = 20;
		accel = 500;
		//maxSpeed = 500;
		damage = 20;
		maxRange = 2000;
		speedX = xLaunchSpeed + (float) Math.cos(angle) * startSpeed;
		speedY = yLaunchSpeed + (float) Math.sin(angle) * startSpeed;
		accelX = (float) Math.cos(angle) * accel;
		accelY = (float) Math.sin(angle) * accel;

		this.x = newX + (float) Math.cos(angle) * length;
		this.y = newY + (float) Math.sin(angle) * length;
		backX = newX;
		backY = newY;
		oldBackX = backX;
		oldBackY = backY;
	}
	transient BasicStroke stroke = new BasicStroke(5);

	public void render(ViewPane viewPane) {
		Graphics2D g = viewPane.getBackImageGraphics2D();
		g.setColor(Color.BLUE);
		//g.fill(new java.awt.geom.Ellipse2D.Float(getX() - radius, getY() - radius, radius * 2f, radius * 2f));
		//System.out.println(this.getClass().getSimpleName()+": render!!!");
		Stroke oldStroke = g.getStroke();
		g.setStroke(stroke);
		g.draw(new Line2D.Float(x, y, backX, backY));//,(float)(x+length*Math.cos(angle)), (float)(y+length*Math.sin(angle))));
		//g.setColor(Color.PINK);
		//g.draw(new Line2D.Float(backX,backY, oldBackX, oldBackY));
		g.setStroke(oldStroke);
	}

	public void doMove(double seconds, double timeAtStartOfMoveSeconds) {
		// using s = ut + 1/2 * at^2 and solving for t, t = (-u (+ or -) (u^2 + 2as)^(1/2)))/a
		double lifeTimeSeconds = (-startSpeed + Math.pow(startSpeed * startSpeed + 2 * accel * maxRange, 0.5f)) / accel;
		assert dead == false && intersected == false : "dead == " + dead + ", intersected == " + intersected;
		assert seconds >= 0 : seconds;
		assert spawnTimeSeconds <= timeAtStartOfMoveSeconds + seconds : "this bullet was spawned in the future! getSSCode() == " + getSSCode() + ", spawnTimeSeconds == " + (spawnTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		assert spawnTimeSeconds + lifeTimeSeconds >= timeAtStartOfMoveSeconds : "getSSCode() == " + getSSCode() + ", spawnTimeSeconds + lifeTimeSeconds == " + (spawnTimeSeconds + lifeTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + lifeTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		if (spawnTimeSeconds + lifeTimeSeconds < timeAtStartOfMoveSeconds + seconds) {
			seconds = spawnTimeSeconds + lifeTimeSeconds - timeAtStartOfMoveSeconds;
			doBulletMove(seconds, timeAtStartOfMoveSeconds);
			dead = true;
		} else {
			doBulletMove(seconds, timeAtStartOfMoveSeconds);
			assert spawnTimeSeconds + lifeTimeSeconds >= timeAtStartOfMoveSeconds : "getSSCode() == " + getSSCode() + ", spawnTimeSeconds + lifeTimeSeconds == " + (spawnTimeSeconds + lifeTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + lifeTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		}
		if (intersected) {
			dead = true;
		}
		oldBackX = backX;
		oldBackY = backY;
	}

	protected void doBulletMove(double seconds, double timeAtStartOfMoveSeconds) {
		assert Double.isNaN(x) == false;
		assert seconds >= 0 : seconds;
		float newSpeedX = (float) (speedX + accelX * seconds);
		float newSpeedY = (float) (speedY + accelY * seconds);
		float xIncrement = (float) (((newSpeedX + speedX) / 2f) * seconds);
		float yIncrement = (float) (((newSpeedY + speedY) / 2f) * seconds);
		x += xIncrement;
		y += yIncrement;
		backX += xIncrement;
		backY += yIncrement;

		speedX = newSpeedX;
		speedY = newSpeedY;


		boolean touch = false;

		ArrayList<Obstacle> obstacles = player.getWorld().getObstacles();
		Obstacle hitObstacle = null;
		Point2D.Double obstacleIntersection = new Point2D.Double();
		float distToClosestHitObstacle = Float.MAX_VALUE;
		Point2D.Double testIntersection = new Point2D.Double();
		for (int i = 0; i < obstacles.size(); i++) {
			Obstacle obstacle = obstacles.get(i);
			KPolygon shape = obstacle.getShape();
			float distCovered = (float) Math.pow(Math.pow(xIncrement, 2) + Math.pow(yIncrement, 2), 0.5f);
			float error = 0.1f;
			if (Point2D.Float.distance(x, y, shape.getCentre().x, shape.getCentre().y) > shape.getCircularBound() + length + distCovered + error) {
				continue;
			}
			Point2D.Float[] points = shape.getPoints();
			for (int j = 0; j < points.length; j++) {
				int jPlus = (j + 1 == points.length ? 0 : j + 1);
				boolean intersects = Player.getLineLineIntersection(oldBackX, oldBackY, x, y, points[j].x, points[j].y, points[jPlus].x, points[jPlus].y, testIntersection);
				if (intersects == false) {
					continue;
				}
				assert Float.isNaN((float) testIntersection.x) == false && Float.isNaN((float) testIntersection.y) == false : testIntersection.x + ", " + testIntersection.y;
				assert Float.isInfinite((float) testIntersection.x) == false && Float.isInfinite((float) testIntersection.y) == false : testIntersection.x + ", " + testIntersection.y;
				float dist = (float) Point2D.Float.distance(oldBackX, oldBackY, testIntersection.x, testIntersection.y);
				if (dist < distToClosestHitObstacle) {
					distToClosestHitObstacle = dist;
					touch = true;
					hitObstacle = obstacle;
					obstacleIntersection.setLocation(testIntersection);
				}
			}
		}

		ArrayList<Player> players = player.getWorld().getPlayers();
		Player hitPlayer = null;
		//Point2D.Double playerIntersection = null;
		float distToClosestHitPlayer = Float.MAX_VALUE;

		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			if (p == player && timeAtStartOfMoveSeconds < spawnTimeSeconds + canNotHitOwnPlayerTimeSeconds) {
				continue;
			}
			if (Line2D.Float.linesIntersect(oldBackX, oldBackY, x, y, p.getOldX(), p.getOldY(), p.getX(), p.getY())) {
				// The below is not really the right distance to where the 
				// player was hit, but it is an OK approximation.
				float dist = (float) Point2D.Float.distance(oldBackX, oldBackY, p.getX(), p.getY());
				if (dist < distToClosestHitPlayer) {
					distToClosestHitPlayer = dist;
					touch = true;
					hitPlayer = p;
				}
			} else if (Line2D.ptSegDist(x, y, oldBackX, oldBackY, p.getX(), p.getY()) < p.getR()) {
				// The below is not really the right distance to where the 
				// player was hit, but it is an OK approximation.
				float dist = (float) Point2D.Float.distance(oldBackX, oldBackY, p.getX(), p.getY());
				if (dist < distToClosestHitPlayer) {
					distToClosestHitPlayer = dist;
					touch = true;
					hitPlayer = p;
				}
			}
		}

		if (touch) {
			if (hitPlayer == this.getPlayer()) {
				System.out.println(this.getClass().getSimpleName() + ": this player was hit by its own bullet, getPlayer() == " + getPlayer() + ", " + timeAtStartOfMoveSeconds + ", " + spawnTimeSeconds + ", " + canNotHitOwnPlayerTimeSeconds);
			}
			if (hitPlayer != null && distToClosestHitPlayer < distToClosestHitObstacle) {
				hitPlayer.takeDamage(this, timeAtStartOfMoveSeconds);
				this.playerThatWasHit = hitPlayer;
				intersected = true;
			} else if (hitObstacle != null) {
				intersected = true;
			}

		}
	}

	public float getDamage() {
		return damage;
	}

	public void setDamage(float damage) {
		this.damage = damage;
	}
}
*/