/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sydneyengine.shooter;

import sydneyengine.superserializable.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;

/**
 *
 * @author CommanderKeith
 */
public class FlameBall extends Bullet {

	static float canNotHitOwnPlayerTimeSeconds = 1.0f;
	static float radius;
	static float length;
	float lifeTimeSeconds;
	static float damage;
	float angle;
	
	int colorNum;
	public static ArrayList<Color> colors = new ArrayList<Color>();
	static{
		colors.add(Color.RED);
		colors.add(Color.ORANGE);
		colors.add(Color.YELLOW);
		colors.add(Color.WHITE);
	}


	public FlameBall() {
		super();
		player = null;
	}

	public FlameBall(FlameThrower gun, Player player, float newX, float newY, float angle, double spawnTimeSeconds, float xLaunchSpeed, float yLaunchSpeed, int colorNum) {
		super(player, newX, newY, angle, spawnTimeSeconds, xLaunchSpeed, yLaunchSpeed);
		assert Point2D.distance(player.getX(), player.getY(), newX, newY) < player.getR() : Point2D.distance(player.getX(), player.getY(), newX, newY);
		this.colorNum = colorNum;
		radius = 2.5f;
		length = 2*radius;
		damage = 6f;
		this.angle = angle;
		gun.getWorld().getRandom().setSeed(gun.getSeed());
		gun.setSeed(gun.getSeed()+341);
		float randomSpeedIncrement = world.getRandom().nextFloat()*400;
		float startSpeed = 70 + randomSpeedIncrement;
		gun.getWorld().getRandom().setSeed(gun.getSeed());
		gun.setSeed(gun.getSeed()+3410);
		float randomRangeIncrement = world.getRandom().nextFloat()*200;
		float range = 200 + randomRangeIncrement;
		speedX = xLaunchSpeed + (float) Math.cos(angle) * startSpeed;
		speedY = yLaunchSpeed + (float) Math.sin(angle) * startSpeed;
		//float accel = -150;
		//accelX = (float) Math.cos(angle) * accel;
		//accelY = (float) Math.sin(angle) * accel;
		float launchSpeed = startSpeed;//(float)Math.sqrt(Math.pow(speedX, 2) + Math.pow(speedY, 2));
		lifeTimeSeconds = range / launchSpeed;
		
		this.x = newX + (float) Math.cos(angle) * length;
		this.y = newY + (float) Math.sin(angle) * length;
		backX = newX;
		backY = newY;
		oldBackX = backX;
		oldBackY = backY;
	}

	public void render(ViewPane viewPane) {
		Graphics2D g = viewPane.getBackImageGraphics2D();
		
		g.setColor(colors.get(colorNum));

		g.fill(new java.awt.geom.Ellipse2D.Float(getX() - radius, getY() - radius, radius * 2f, radius * 2f));
	}

	public float getDamage(){
		return damage;
	}

	public double getLifeTimeSeconds(){
		return lifeTimeSeconds;
	}
	public float getLength(){
		return length;
	}
	public float getCanNotHitOwnPlayerTimeSeconds(){
		return canNotHitOwnPlayerTimeSeconds;
	}
	
	
}




/*
package sydneyengine;

import sydneyengine.superserializable.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;

public class FlameBall extends Bullet {

	static float canNotHitOwnPlayerTimeSeconds = 1.0f;
	protected float maxRange;
	float radius;
	float maxSpeed;
	float damage;
	float oldX, oldY = 0;
	
	int colorNum;
	public static ArrayList<Color> colors = new ArrayList<Color>();
	static{
		colors.add(Color.RED);
		colors.add(Color.ORANGE);
		colors.add(Color.YELLOW);
		colors.add(Color.WHITE);
	}
	
	public FlameBall() {
		super();
	}

	public FlameBall(Player player, float x, float y, float angle, double spawnTimeSeconds, float xLaunchSpeed, float yLaunchSpeed, int colorNum) {
		super(player, x, y, angle, spawnTimeSeconds, xLaunchSpeed, yLaunchSpeed);
		this.x = x;
		this.y = y;
		oldX = x;
		oldY = y;
		maxSpeed = 120;
		radius = 4.0f;
		damage = 2.3333f;
		maxRange = 70;
		//xLaunchSpeed = 0;
		//yLaunchSpeed = 0;
		speedX = xLaunchSpeed + (float) Math.cos(angle) * maxSpeed;
		speedY = yLaunchSpeed + (float) Math.sin(angle) * maxSpeed;
		this.colorNum = colorNum;
	}
	
	//transient BasicStroke stroke = new BasicStroke(3);
	public void render(ViewPane viewPane) {
		Graphics2D g = viewPane.getBackImageGraphics2D();
		
		g.setColor(colors.get(colorNum));

		g.fill(new java.awt.geom.Ellipse2D.Float(getX() - radius, getY() - radius, radius * 2f, radius * 2f));
	}
	
	public void doMove(double seconds, double timeAtStartOfMoveSeconds) {
		double lifeTimeSeconds = maxRange / maxSpeed;
		assert dead == false : "dead == " + dead;
		assert seconds >= 0 : seconds;
		assert spawnTimeSeconds <= timeAtStartOfMoveSeconds + seconds : "this bullet was spawned in the future! getSSCode() == " + getSSCode() + ", spawnTimeSeconds == " + (spawnTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		assert dead == true || spawnTimeSeconds + lifeTimeSeconds >= timeAtStartOfMoveSeconds : "getSSCode() == " + getSSCode() + ", spawnTimeSeconds + lifeTimeSeconds == " + (spawnTimeSeconds + lifeTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + lifeTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		if (spawnTimeSeconds + lifeTimeSeconds < timeAtStartOfMoveSeconds + seconds) {
			seconds = spawnTimeSeconds + lifeTimeSeconds - timeAtStartOfMoveSeconds;
			doBulletMove(seconds, timeAtStartOfMoveSeconds);
			dead = true;
		} else {
			doBulletMove(seconds, timeAtStartOfMoveSeconds);
			assert spawnTimeSeconds + lifeTimeSeconds >= timeAtStartOfMoveSeconds : "getSSCode() == " + getSSCode() + ", spawnTimeSeconds + lifeTimeSeconds == " + (spawnTimeSeconds + lifeTimeSeconds) + ", timeAtStartOfMoveSeconds + seconds == " + (timeAtStartOfMoveSeconds + seconds) + ", " + spawnTimeSeconds + ", " + lifeTimeSeconds + ", " + timeAtStartOfMoveSeconds + ", " + seconds;
		}
		if (intersected) {
			dead = true;
		}
		oldX = x;
		oldY = y;
	}

	protected void doBulletMove(double seconds, double timeAtStartOfMoveSeconds) {
		assert Double.isNaN(x) == false;
		assert seconds >= 0 : seconds;
		float accelX = 0f;
		float accelY = 0f;
		float newSpeedX = (float) (speedX + accelX * seconds);
		float newSpeedY = (float) (speedY + accelY * seconds);
		float xIncrement = (float) (((newSpeedX + speedX) / 2f) * seconds);
		float yIncrement = (float) (((newSpeedY + speedY) / 2f) * seconds);
		x += xIncrement;
		y += yIncrement;
		speedX = newSpeedX;
		speedY = newSpeedY;
		assert intersected == false : intersected;

		boolean touch = false;
		
		ArrayList<Obstacle> obstacles = player.getWorld().getObstacles();
		Obstacle hitObstacle = null;
		Point2D.Double obstacleIntersection = new Point2D.Double();
		float distToClosestHitObstacle = Float.MAX_VALUE;
		Point2D.Double testIntersection = new Point2D.Double();
		for (int i = 0; i < obstacles.size(); i++) {
			Obstacle obstacle = obstacles.get(i);
			KPolygon shape = obstacle.getShape();
			float distCovered = (float) Math.pow(Math.pow(xIncrement, 2) + Math.pow(yIncrement, 2), 0.5f);
			float error = 0.1f;
			if (Point2D.Float.distance(x, y, shape.getCentre().x, shape.getCentre().y) > shape.getCircularBound() + radius + distCovered + error) {
				continue;
			}
			Point2D.Float[] points = shape.getPoints();
			for (int j = 0; j < points.length; j++) {
				int jPlus = (j + 1 == points.length ? 0 : j + 1);
				//if (Line2D.Float.linesIntersect(oldX, oldY, x, y, points[j].x, points[j].y, points[jPlus].x, points[jPlus].y)){
				boolean intersects = Player.getLineLineIntersection(oldX, oldY, x, y, points[j].x, points[j].y, points[jPlus].x, points[jPlus].y, testIntersection);
				if (intersects == false) {
					//System.out.println(this.getClass().getSimpleName()+": Line2D.Float.linesIntersect says intersection fo obstacle with bullet, but Player.getLineLineIntersection says not.");
					continue;
				}
				assert Float.isNaN((float) testIntersection.x) == false && Float.isNaN((float) testIntersection.y) == false : testIntersection.x + ", " + testIntersection.y;
				assert Float.isInfinite((float) testIntersection.x) == false && Float.isInfinite((float) testIntersection.y) == false : testIntersection.x + ", " + testIntersection.y;
				float dist = (float) Point2D.Float.distance(oldX, oldY, testIntersection.x, testIntersection.y);
				assert dist >= 0 : dist;
				if (dist < distToClosestHitObstacle) {
					distToClosestHitObstacle = dist;
					touch = true;
					hitObstacle = obstacle;
					obstacleIntersection.setLocation(testIntersection);
				}
			}
		}

		ArrayList<Player> players = player.getWorld().getPlayers();
		Player hitPlayer = null;
		//Point2D.Double playerIntersection = null;
		float distToClosestHitPlayer = Float.MAX_VALUE;
		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			if (p == player && timeAtStartOfMoveSeconds < spawnTimeSeconds + canNotHitOwnPlayerTimeSeconds) {
				continue;
			}
			if (Line2D.linesIntersect(oldX, oldY, x, y, p.getOldX(), p.getOldY(), p.getX(), p.getY())) {
				// The below is not really the right distance to where the 
				// player was hit, but it is an OK approximation.
				float dist = (float) Point2D.Float.distance(oldX, oldY, p.getX(), p.getY());
				if (dist < distToClosestHitPlayer) {
					distToClosestHitPlayer = dist;
					touch = true;
					hitPlayer = p;
				}
			// Note: excluding this bullet's radius in below line of code since then the bullet won't hit the player 
			// unless its centre went through the player, which is consistent with bullet collision with obstacles above.
			} else if (Line2D.ptSegDist(x, y, oldX, oldY, p.getX(), p.getY()) < p.getR()) {
				// The below is not really the right distance to where the 
				// player was hit, but it is an OK approximation.
				float dist = (float) Point2D.Float.distance(oldX, oldY, p.getX(), p.getY());
				if (dist < distToClosestHitPlayer) {
					distToClosestHitPlayer = dist;
					touch = true;
					hitPlayer = p;
				}
			}
		}
		if (touch) {
			if (hitPlayer == this.getPlayer()) {
				System.out.println(this.getClass().getSimpleName() + ": this player was hit by its own bullet, getPlayer() == " + getPlayer() + ", " + timeAtStartOfMoveSeconds + ", " + spawnTimeSeconds + ", " + canNotHitOwnPlayerTimeSeconds);
			}
			if (hitPlayer != null && distToClosestHitObstacle > distToClosestHitPlayer) {
				hitPlayer.takeDamage(this, timeAtStartOfMoveSeconds);
				this.playerThatWasHit = hitPlayer;
				intersected = true;
			} else if (hitObstacle != null) {
				intersected = true;
			}
		}
	}
	
	
	public float getDamage() {
		return damage;
	}

	public void setDamage(float damage) {
		this.damage = damage;
	}*/

