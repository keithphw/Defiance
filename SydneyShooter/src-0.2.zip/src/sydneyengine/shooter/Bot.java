/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sydneyengine.shooter;

import java.util.*;
import java.awt.geom.*;

/**
 *
 * @author Phillip
 */
public class Bot extends Player{
	final static int NORTH_TEAM = 1;
	final static int SOUTH_TEAM = 2;
	int pathNum;
	int pathPointNum;
	static ArrayList<ArrayList<Point2D.Float>> northTeamPaths = new ArrayList<ArrayList<Point2D.Float>>();
	static ArrayList<ArrayList<Point2D.Float>> southTeamPaths = new ArrayList<ArrayList<Point2D.Float>>();
	static{
		ArrayList<Point2D.Float> northTeamPathToSecurableFlag = new ArrayList<Point2D.Float>();
		northTeamPathToSecurableFlag.add(new Point2D.Float(700,80));
		northTeamPathToSecurableFlag.add(new Point2D.Float(720,300));
		northTeamPathToSecurableFlag.add(new Point2D.Float(775,600));
		northTeamPathToSecurableFlag.add(new Point2D.Float(930,1120));
		northTeamPathToSecurableFlag.add(new Point2D.Float(497,1197));
		ArrayList<Point2D.Float> northTeamPathToSecurableFlag2 = new ArrayList<Point2D.Float>();
		northTeamPathToSecurableFlag2.add(new Point2D.Float(600,40));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(250,60));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(100,450));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(120,600));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(270,720));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(345,780));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(320,840));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(70,850));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(100,1120));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(100,1120));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(230,1250));
		northTeamPathToSecurableFlag2.add(new Point2D.Float(503,1203));
		
		ArrayList<Point2D.Float> northTeamPathToCapturableFlag = new ArrayList<Point2D.Float>();
		northTeamPathToCapturableFlag.add(new Point2D.Float(510,1190));
		northTeamPathToCapturableFlag.add(new Point2D.Float(600,1150));
		northTeamPathToCapturableFlag.add(new Point2D.Float(800,1160));
		northTeamPathToCapturableFlag.add(new Point2D.Float(930,1270));
		northTeamPathToCapturableFlag.add(new Point2D.Float(920,1520));
		northTeamPathToCapturableFlag.add(new Point2D.Float(720,1530));
		northTeamPathToCapturableFlag.add(new Point2D.Float(650,1600));
		northTeamPathToCapturableFlag.add(new Point2D.Float(670,1620));
		northTeamPathToCapturableFlag.add(new Point2D.Float(830,1850));
		northTeamPathToCapturableFlag.add(new Point2D.Float(700,1920));
		northTeamPathToCapturableFlag.add(new Point2D.Float(810,2080));
		northTeamPathToCapturableFlag.add(new Point2D.Float(800,2200));
		ArrayList<Point2D.Float> northTeamPathToCapturableFlag2 = new ArrayList<Point2D.Float>();
		northTeamPathToCapturableFlag2.add(new Point2D.Float(490,1210));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(180,1250));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(70,1350));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(400,1670));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(500,2000));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(630,2200));
		northTeamPathToCapturableFlag2.add(new Point2D.Float(800,2200));
		
		ArrayList<Point2D.Float> northTeamPathToCapturableFlagReversed = new ArrayList<Point2D.Float>();
		for (int i = northTeamPathToCapturableFlag.size()-1; i >= 0; i--){
			northTeamPathToCapturableFlagReversed.add(northTeamPathToCapturableFlag.get(i));
		}
		
		ArrayList<Point2D.Float> northTeamPathToCapturableFlag2Reversed = new ArrayList<Point2D.Float>();
		for (int i = northTeamPathToCapturableFlag2.size()-1; i >= 0; i--){
			northTeamPathToCapturableFlag2Reversed.add(northTeamPathToCapturableFlag2.get(i));
		}
		
		northTeamPaths.add(northTeamPathToSecurableFlag);
		northTeamPaths.add(northTeamPathToSecurableFlag2);
		northTeamPaths.add(northTeamPathToCapturableFlag);
		northTeamPaths.add(northTeamPathToCapturableFlag2);
		northTeamPaths.add(northTeamPathToCapturableFlagReversed);
		northTeamPaths.add(northTeamPathToCapturableFlag2Reversed);
		
		for (int i = 0; i < northTeamPaths.size(); i++){
			ArrayList<Point2D.Float> newSouthTeamPath = new ArrayList<Point2D.Float>();
			for (int j = 0; j < northTeamPaths.get(i).size(); j++){
				newSouthTeamPath.add(new Point2D.Float(GameWorld.getWidth()-northTeamPaths.get(i).get(j).x, GameWorld.getHeight()-northTeamPaths.get(i).get(j).y));
			}
			southTeamPaths.add(newSouthTeamPath);
		}
	}
	
	public Bot(){
		super();
		numTimeStops = 0;
		timeStopMultiple = 0.05;
	}
	
	public void addKill(){
		super.addKill();
		//world.addChatText(new ChatText(this, "Oxygen theif", false, world.getTotalElapsedSeconds()));
	}
	public void addDeath(){
		super.addDeath();
		//world.addChatText(new ChatText(this, "I'll get you next time", false, world.getTotalElapsedSeconds()));
	}
	
	public void respawn() {
		super.respawn();
		world.incrementAndReSeedRandom();
		if (getTeam().getSpawnFlags().size() > 1){
			world.incrementAndReSeedRandom();
			// the middle base is captured, so no need to run over to it and can instead go straight for the capturable flag.
			pathNum = world.getRandom().nextInt(2) + 2;
		}else{
			world.incrementAndReSeedRandom();
			pathNum = world.getRandom().nextInt(2);
		}
		pathPointNum = 0;
		Gun botGun = null;
		int numGuns = 5;
		world.incrementAndReSeedRandom();
		int randomInt = world.getRandom().nextInt(numGuns);
		if (randomInt == 0){
			botGun = new Pistol(world);
		}else if (randomInt == 1){
			botGun = new FlameThrower(world);
		}else if (randomInt == 2){
			botGun = new ShotGun(world);
		}else if (randomInt == 3){
			botGun = new MachineGun(world);
		}else if (randomInt == 4){
			botGun = new SniperRifle(world);
		}else if (randomInt == 5){
			botGun = new RocketLauncher(world);
		}
		addAndUseGun(botGun);
		//this.setSpeedMultiplier(2, world.getTotalElapsedSeconds(), Double.MAX_VALUE);
	}
	
	public Player getClosestEnemy(){
		if (this.getGun().getTotalAmmo() == 0){
			return null;
		}
		Player closestPlayer = null;
		double closestDist = Double.MAX_VALUE;
		for (Player player : world.getPlayers()){
			if (player.isDead() || (player.isInvisible() && player.getGun().isFiring() == false) || player.getTeam() == getTeam()){
				continue;
			}
			if (Point2D.distance(player.getX(), player.getY(), getX(), getY()) < closestDist){
				if (isPlayerShootable(player)){
					closestDist = Point2D.distance(player.getX(), player.getY(), getX(), getY());
					closestPlayer = player;
				}
			}
		}
		return closestPlayer;
	}
	
	protected boolean isPlayerShootable(Player player){
		if (Point2D.distance(player.getX(), player.getY(), getX(), getY()) > getGun().getRangeForBotAiming()){
			return false;
		}
		ArrayList<Obstacle> obstacles = getWorld().getObstacles();
		for (int i = 0; i < obstacles.size(); i++) {
			Obstacle obstacle = obstacles.get(i);
			KPolygon shape = obstacle.getShape();
//			if (Point2D.Float.distance(x, y, shape.getCentre().x, shape.getCentre().y) > shape.getCircularBound() + radius) {
//				continue;
//			}
			Point2D.Float[] points = shape.getPoints();
			for (int j = 0; j < points.length; j++) {
				int jPlus = (j + 1 == points.length ? 0 : j + 1);
				if (Line2D.Float.linesIntersect(getX(), getY(), player.getX(), player.getY(), points[j].x, points[j].y, points[jPlus].x, points[jPlus].y)) {
					return false;
				}
			}
		}
		return true;
	}
	
	
	double timeStopMultiple;
	int numTimeStops;
	
	public void doMove(double seconds, double timeAtStartOfMoveSeconds) {
		assert seconds >= 0 : seconds;
		double nextTimeStop = timeStopMultiple * numTimeStops;
		double timeAtEndOfMoveSeconds = timeAtStartOfMoveSeconds + seconds;
		//System.out.println(this.getClass().getSimpleName() + ": timeAtStartOfMoveSeconds == "+timeAtStartOfMoveSeconds+", timeAtEndOfMoveSeconds == "+timeAtEndOfMoveSeconds+", seconds == "+seconds+", nextTimeStop == "+nextTimeStop);
		while (nextTimeStop <= timeAtEndOfMoveSeconds) {
			double reducedSeconds = nextTimeStop - timeAtStartOfMoveSeconds;
			if (reducedSeconds < 0){
				reducedSeconds = 0;
			}
			if (reducedSeconds != 0){
				//System.out.println(this.getClass().getSimpleName() + ": doMove2(reducedSeconds, timeAtStartOfMoveSeconds), reducedSeconds == "+reducedSeconds+", timeAtStartOfMoveSeconds == "+timeAtStartOfMoveSeconds);
				doMove2(reducedSeconds, timeAtStartOfMoveSeconds);
			}
			nowAtTimeStop(nextTimeStop);
			timeAtStartOfMoveSeconds = nextTimeStop;
			if (timeAtEndOfMoveSeconds == nextTimeStop){
				seconds = 0;
			}else{
				seconds -= reducedSeconds;
			}
			numTimeStops++;
			nextTimeStop = timeStopMultiple * numTimeStops;
		}
		if (seconds > 0){
			//System.out.println(this.getClass().getSimpleName() + ": doMove2(seconds, timeAtStartOfMoveSeconds), seconds == "+seconds+", timeAtStartOfMoveSeconds == "+timeAtStartOfMoveSeconds);
			doMove2(seconds, timeAtStartOfMoveSeconds);
		}
	}
	
	static int minDist = 20;
	protected void nowAtTimeStop(double timeAtStartOfMoveSeconds){
		// only bother doing the bot stuff if there's a human player to watch what's happening..
		if (isHumanPlayerInGame() == true){
			if (this.getGun().getTotalAmmo() == 0){
				this.cycleGunsForwardBy(1, timeAtStartOfMoveSeconds);
			}
			Player closestEnemy = getClosestEnemy();
			if (closestEnemy != null){
				float targetForMoveX = closestEnemy.getX() - getX();
				float targetForMoveY = closestEnemy.getY() - getY();
				this.setMouseTargetX(targetForMoveX);
				this.setMouseTargetY(targetForMoveY);
				this.getGun().startFiring(timeAtStartOfMoveSeconds);
				this.setUp(false);
			}else{
				ArrayList<Point2D.Float> currentPath = getTeamPaths().get(pathNum);
				Point2D.Float targetPointForMove = currentPath.get(pathPointNum);
				boolean doNothingUntilFlagSecured = false;
				while (targetPointForMove.distance(getX(), getY()) < minDist){
					pathPointNum++;
					if (pathPointNum >= currentPath.size()){
						pathPointNum = 0;
						if (pathNum == 0 || pathNum == 1 || pathNum == 4 || pathNum == 5){
							world.incrementAndReSeedRandom();
							pathNum = world.getRandom().nextInt(2) + 2;
							currentPath = getTeamPaths().get(pathNum);
						}else if (pathNum == 2 || pathNum == 3){
							world.incrementAndReSeedRandom();
							pathNum = world.getRandom().nextInt(2)+4;
							currentPath = getTeamPaths().get(pathNum);
						}
					}
					targetPointForMove = currentPath.get(pathPointNum);
				}
				if (getWorld().getSecurableFlag().getTeam() != this.getTeam() && 
						Point2D.distance(getWorld().getSecurableFlag().getX(), getWorld().getSecurableFlag().getY(), getX(), getY()) < getWorld().getSecurableFlag().radius){
					// the bot is at the middle capturable flag, but its team hasn't captured it yet, so bot should wait until the base is secured.
					this.setUp(false);
					this.getGun().stopFiring();
				}else{
					float targetForMoveX = targetPointForMove.x - getX();
					float targetForMoveY = targetPointForMove.y - getY();
					this.setMouseTargetX(targetForMoveX);
					this.setMouseTargetY(targetForMoveY);
					this.setUp(true);
					this.getGun().stopFiring();
				}
			}
		}
	}
	
	public void doMove2(double seconds, double timeAtStartOfMoveSeconds) {
		assert seconds >= 0 : seconds;
		double timeAtEndOfMoveSeconds = timeAtStartOfMoveSeconds + seconds;
		super.doMove(seconds, timeAtStartOfMoveSeconds);
		//System.out.println(this.getClass().getSimpleName() + ": doMove2(seconds, timeAtStartOfMoveSeconds), seconds == "+seconds+", timeAtStartOfMoveSeconds == "+timeAtStartOfMoveSeconds);
	}
	
	public boolean isHumanPlayerInGame(){
		for (Player player : world.getPlayers()){
			if (player instanceof Bot == false){
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<ArrayList<Point2D.Float>> getTeamPaths(){
		if (getTeam().getName().equals("BLUE")){
			return northTeamPaths;
		}else{
			return southTeamPaths;
		}
	}
}
